"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var CarPart = /** @class */ (function () {
    function CarPart() {
    }
    return CarPart;
}());
exports.CarPart = CarPart;
//# sourceMappingURL=CarPart.js.map