"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
require("rxjs/Rx");
var book_service_1 = require("./book.service");
var AppComponent = /** @class */ (function () {
    function AppComponent(bookService) {
        this.bookService = bookService;
        this.name = "Angular2";
        this.versionnum = 2;
        this.year = {
            "Releases1": 2010,
            "Releases2": 2013,
            "Releases3": 2015
        };
        this.teams = [{
                "id": 1,
                "name": "misco"
            },
            {
                "id": 2,
                "name": "igor"
            },
            {
                "id": 3,
                "name": "Brad"
            }];
    }
    AppComponent.prototype.MyData = function () {
        var _this = this;
        alert("clicked");
        this.observableBooks = this.bookService.getBooksWithObservable();
        this.observableBooks.subscribe(function (books) { return _this.books = books; }, function (error) { return _this.errorMessage = error; });
    };
    AppComponent.prototype.totalTeams = function () {
        return 9;
    };
    AppComponent.prototype.onclickHan = function () {
        alert("kk");
        this.name = "changed";
    };
    AppComponent = __decorate([
        core_1.Component({
            selector: 'my-app',
            template: "<h1>My First Angular 2 Apps</h1> \n                <p> {{name | uppercase}}</p>\n                <p  class=\"red\"> version:{{  versionnum}} -{{year.Releases1}} use it for single array </p>\n<ul>\n<li *ngFor=\"let members of teams\">\n<h2>{{members.name}} </h2>\n\n</li>\n\n<h1>Total Members:{{teams.length}}</h1>\n<h2> There are {{    totalTeams()}} participated .</h2>\n</ul>\n\n<h1> New Events - Two way binding -  for this need to import Forms/Module</h1>\n<input type=\"text\" [(ngModel)]=\"names\">\n<p>{{names}}</p>\n<button (click)=\"onclickHan()\">Click Here to change firts Class</button>\n\n<button  class=\"btn btn-default\" (click)=\"MyData()\">Click here to see Api</button>\n\n<h3>Book Details with Observable</h3>\n<ul class=\"list-group\">\n  <li  class=\"list-group-item\" *ngFor=\"let book of observableBooks | async\" >\n    Id: {{book.id}}, Name: {{book.name}} - Book length {{observableBooks.length}}\n  </li>\n<li></li>\n\n</ul>\n<p> Routing Area Welcome</p>\n<div>\n    <a [routerLink]=\"['/']\">Home</a>\n    <a [routerLink]=\"['/about']\">About</a>\n    <a [routerLink]=\"['/books']\">Books</a>\n    <div class=\"outer-outlet\">\n    <router-outlet> </router-outlet>\n    </div>\n",
            styles: [".red{\n               color:red;\n                font-size:19px;}"],
            providers: [book_service_1.BookService]
        }),
        __metadata("design:paramtypes", [book_service_1.BookService])
    ], AppComponent);
    return AppComponent;
}());
exports.AppComponent = AppComponent;
var Student = /** @class */ (function () {
    function Student() {
        this.name = "udemy";
    }
    Student.prototype.onclickHan = function () {
        alert("kk");
        this.name = "changed";
    };
    return Student;
}());
//export let car: CarPart[] = [{
//}];
//# sourceMappingURL=app.component.js.map